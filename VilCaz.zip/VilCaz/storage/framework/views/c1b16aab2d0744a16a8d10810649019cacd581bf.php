<!-- Right Side Of Navbar -->




























<!-- header starts -->
<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php echo $__env->yieldContent('content'); ?>


<!-- footer starts -->

<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- footer ends -->

<meta name="_token" content="<?php echo csrf_token(); ?>"/>

<script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/plugins.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/configurator.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/index.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/index.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/tinymce/src/assets/js/tinymce/tinymce.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jssocials/jssocials.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/over.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/over.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lead-full.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/generic.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>


<script>
    function payWithPaystack(){
        var handler = PaystackPop.setup({
            key: 'pk_live_b35ccca36d5bb37bb457e64cc835e2d8f9e0d52c',
            email: 'achimuguaemmanuel01@gmail.com',
            amount: 10000 * 100,
            ref: 'ViliqCaz'+Math.floor((Math.random() * 1000000000) + 1), // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
            firstname: 'Emmanue',
            lastname: 'Achimugu',
            metadata: {
                custom_fields: [
                    {
                        display_name: "Emmanuel",
                        variable_name: "mobile_number",
                        value: "++2348038487703"
                    }
                ]
            },
            callback: function(response){
                alert('Transaction Successful. transaction reference is ' + response.reference);
            },
            onClose: function(){
                alert('Transaction Terminated Successfuly');
            }
        });
        handler.openIframe();
    }
</script>


</body>
</html>
