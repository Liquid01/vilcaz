;

<?php $__env->startSection('content'); ?>
    <!-- Page content -->
    <div id="page-content-wrapper">
        <div class="page-content">
            <!-- Content Header (Page header) -->
            <section class="content-header z-depth-1">
                <div class="header-icon">
                    <i class="fa fa-group"></i>
                </div>
                <div class="header-title">
                    <h1> Member</h1>
                    <small> Credited members</small>
                    <ul class="link hidden-xs">
                        <li><a href="<?php echo e(route('agentHome')); ?>"><i class="fa fa-home"></i>Dashboard</a></li>
                        <li><a href="<?php echo e(route('agentAllMembers')); ?>">my members</a></li>
                    </ul>
                </div>
            </section>
            <!-- page section -->
            <div class="container-fluid">
                <div class="row">
                    <!-- Data tables -->
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="card">
                            <div class="card-header">
                                <i class="fa fa-group fa-lg"></i>
                                <h2>Credited Members</h2>
                            </div>
                            <div class="card-content">
                                <div class="table-responsive">
                                    <table id="data" class="table table-bordered table-striped table-hover">
                                        <thead>

                                        <tr>
                                            <th>NAME</th>
                                            <th>Username</th>
                                            <th>Voucher Quantity</th>
                                            <th>Price</th>
                                            <th>Amount</th>

                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($member->name); ?></td>
                                            <td><?php echo e($member->username); ?></td>
                                            <td><?php echo e($member->voucher_quantity); ?></td>
                                            <td><?php echo e($member->voucher_unit_price); ?></td>
                                            <td><?php echo e(number_format($member->sales_amount, 2)); ?></td>
                                            
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ./Data table -->

                    <!-- ./Data tables -->
                    <!-- ./row -->
                </div>
                <!-- ./cotainer -->
            </div>
            <!-- ./page-content -->
        </div>
        <!-- ./page-content-wrapper -->
    </div>
    <!-- ./page-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('agent.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>