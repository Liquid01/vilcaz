<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('failed')): ?>
    <div class="alert alert-danger alert-dismissible">
        <?php echo e(session('failed')); ?>

    </div>
<?php endif; ?>

<?php if(session('sales')): ?>
    <div class=" row alert alert-success alert-dismissible">
        <div class="col-md-6 col-sm-6">
            <p style="font-weight: bold;"><?php echo e(session('sales')->Quantity); ?> &nbsp; Pins Sold successfully! With
                ID: <?php echo e(session('sales')->Code); ?></p>
        </div>
        <div class="col-md-3 col-sm-3">
            With Amount: &nbsp; NGN <?php echo e(session('sales')->Amount); ?>

        </div>

        <div class="col-md-2 col-sm-2">
            <a href="<?php echo e(route('storeInvoice', session('sales')->Code)); ?>" class="btn btn-primary btn-raised pull-right"
               style="margin: 0px!important;">Details</a>
        </div>
    </div>
<?php endif; ?>









