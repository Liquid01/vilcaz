<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VoucherSales extends Model
{
    protected $guarded = [];
}
