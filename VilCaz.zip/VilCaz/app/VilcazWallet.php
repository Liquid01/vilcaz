<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VilcazWallet extends Model
{
    //

    protected $guarded = [];
}
