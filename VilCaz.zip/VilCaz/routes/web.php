<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/', function () {
    return view('index')->with('page', 'home');
});

Route::get('/whitepaper', function () {
    return view('whitepaper')->with('page', 'whitepaper');
});

Route::get('/register', function () {
    return view('auth.register')->with('page', 'register');
});

Route::get('/register/{username}', 'Auth\RegisterController@registerReferrer');

Route::get('/contact', function () {
    return view('contact')->with('page', 'contact');
});

Route::get('/compensation', function () {
    return view('compensation')->with('page', 'compensation');
});

Route::get('/user/verify/{token}', 'Auth\RegisterController@verifyUser');

Route::post('/verifyTransaction', 'TransactionsController@verifyPayment')->name('verifyTransactionRef');

//*******************************ADMIN ROUTES***********************/

Route::group(['prefix' => 'admin', 'middleware' => 'admin'], function (){

    Route::get('/home', 'AdminController@index')->name('adminHome');
    Route::get('/creditVoucher', 'AdminController@creditVoucher')->name('creditVoucher');
    Route::post('/creditVoucher', 'AdminController@postVoucher')->name('postVoucher');

//    members
    Route::get('/members', 'MemberController@index')->name('adminAllMembers');
    Route::get('/members/{member}', 'MemberController@show')->name('adminMemberDetails');

});



//*******************************AGENTS ROUTES***********************/

Route::group(['prefix' => 'agent', 'middleware' => 'agents'], function (){

    Route::get('/home', 'AgentController@index')->name('agentHome');
    Route::get('/creditVoucher', 'AgentController@creditVoucher')->name('agentCreditVoucher');
    Route::post('/creditVoucher', 'AgentController@postVoucher')->name('agentPostVoucher');

//    members
    Route::get('/members', 'AgentController@members')->name('agentAllMembers');
    Route::get('/members/{member}', 'AgentController@show')->name('agentMemberDetails');

});


Route::group(['prefix' => 'members', 'middleware' => 'members'], function (){

    Route::get('/referrals', 'ReferralController@index')->name('myReferrals');
    Route::get('/bonus', 'ReferralController@referralBonus')->name('myReferralBonus');

//    members
//    Route::get('/members', 'MemberController@index')->name('adminAllMembers');

});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/verify/{token}', 'verifyController@verify')->name('verify');
